package com.example.clashassistant;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.IBinder;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Toast;
import android.graphics.drawable.GradientDrawable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class OverlayService extends Service {
    private WindowManager wm;
    private View bubble;
    private View panel;
    private final List<String> enemyCards = new ArrayList<>();
    private final List<String> winConditions = Arrays.asList("Hog Rider","Balloon","Goblin Barrel","Goblin Drill","Giant","Golem","Graveyard","Lava Hound","Mortar","Royal Giant","Royal Hogs","Ram Rider","Wall Breakers","X-Bow","Electro Giant","Sparky","Battle Ram","Miner","Skeleton Barrel","P.E.K.K.A");
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    @Override public void onCreate(){
        super.onCreate(); wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        Button b=new Button(this); b.setText("AI"); b.setTextColor(Color.WHITE); b.setTextSize(14); b.setAllCaps(false);
        GradientDrawable bg=new GradientDrawable(); bg.setColor(Color.rgb(105,65,220)); bg.setCornerRadius(dp(32)); b.setBackground(bg);
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(dp(58),dp(58),WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);
        p.gravity=Gravity.RIGHT|Gravity.CENTER_VERTICAL; p.x=dp(10); bubble=b; wm.addView(bubble,p);
        b.setOnClickListener(v->togglePanel());
        b.setOnTouchListener(new View.OnTouchListener(){float sx,sy; int ox,oy; long down;
            public boolean onTouch(View v, android.view.MotionEvent e){
                if(e.getAction()==0){sx=e.getRawX();sy=e.getRawY();ox=p.x;oy=p.y;down=System.currentTimeMillis();return false;}
                if(e.getAction()==2){p.x=ox+(int)(sx-e.getRawX());p.y=oy+(int)(e.getRawY()-sy);wm.updateViewLayout(bubble,p);return true;}
                if(e.getAction()==1 && (Math.abs(e.getRawX()-sx)>dp(8)||Math.abs(e.getRawY()-sy)>dp(8)))return true;
                return false;
            }});
    }
    private TextView text(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(size);t.setPadding(dp(8),dp(7),dp(8),dp(7));return t;}
    private Button btn(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(33,52,82)));return b;}
    private void togglePanel(){if(panel!=null){wm.removeView(panel);panel=null;return;} buildPanel();}
    private void buildPanel(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(12),dp(10),dp(12),dp(10));root.setBackgroundColor(Color.rgb(12,20,39));
        TextView head=text("⚡ CLASH AI     [ × ]",20);head.setTypeface(null,Typeface.BOLD);root.addView(head);head.setOnClickListener(v->{wm.removeView(panel);panel=null;});
        LinearLayout tabs=new LinearLayout(this); tabs.setOrientation(LinearLayout.HORIZONTAL);
        for(String tab:new String[]{"Deck","Finder","WinCon"}){Button x=btn(tab);tabs.addView(x,new LinearLayout.LayoutParams(0,-2,1));x.setOnClickListener(v->showTab(tab));}root.addView(tabs);
        TextView body=text("Wybierz moduł powyżej. W meczu dodawaj karty przeciwnika ręcznie. Automatyczne czytanie ekranu nie jest jeszcze zaimplementowane.",14);body.setTag("body");root.addView(body);
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(getResources().getDisplayMetrics().widthPixels-dp(32),WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
        p.gravity=Gravity.CENTER;panel=root;wm.addView(panel,p);
    }
    private void showTab(String tab){
        if(panel==null)return;
        LinearLayout root=(LinearLayout)panel;
        TextView body=(TextView)root.findViewWithTag("body");
        if(body==null)return;
        if(tab.equals("Deck")) body.setText("DECK ANALYZER\nWpisz 8 kart w kolejnej wersji modułu. Ocena obejmie win condition, zaklęcia i balans.");
        if(tab.equals("Finder")) body.setText("ENEMY DECK FINDER\nDodane karty: "+(enemyCards.isEmpty()?"brak":android.text.TextUtils.join(", ",enemyCards))+"\nWzorzec: "+detectDeck()+"\n\n");
        if(tab.equals("WinCon")) body.setText("WIN CONDITION PREDICTION\n"+(enemyCards.isEmpty()?"Czekam na pierwszą kartę przeciwnika.":"Możliwe win condition: "+possibleWins()));
        if(tab.equals("Finder")||tab.equals("WinCon")){
            Button add=btn("Dodaj kartę przeciwnika");
            root.addView(add,root.indexOfChild(body)+1);
            add.setOnClickListener(v->showCardPicker());
        }
    }
    private void showCardPicker(){
        final String[] choices={"Princess","Goblin Barrel","Inferno Tower","Knight","Log","Goblin Gang","Hog Rider","Musketeer","Cannon","Fireball","Ice Golem","Ice Spirit","Skeletons","Balloon","Lava Hound","Golem","Graveyard","Royal Giant","Miner","Poison","X-Bow","Tesla","P.E.K.K.A","Bandit","Battle Ram","Valkyrie","Other / Homemade"};
        android.app.AlertDialog.Builder b=new android.app.AlertDialog.Builder(this);
        b.setTitle("Karta przeciwnika").setItems(choices,(d,w)->{if(!enemyCards.contains(choices[w]))enemyCards.add(choices[w]);showTab("Finder");});
        b.setNegativeButton("Anuluj",null).show();
    }
    private String detectDeck(){
        if(enemyCards.contains("Goblin Barrel")&&(enemyCards.contains("Princess")||enemyCards.contains("Inferno Tower")))return "Log Bait (prawdopodobny)";
        if(enemyCards.contains("Hog Rider")&&(enemyCards.contains("Musketeer")||enemyCards.contains("Cannon")))return "Hog Cycle (możliwy)";
        if(enemyCards.contains("Lava Hound")&&enemyCards.contains("Balloon"))return "LavaLoon (możliwy)";
        if(enemyCards.contains("X-Bow")&&enemyCards.contains("Tesla"))return "X-Bow Cycle (możliwy)";
        if(enemyCards.contains("Other / Homemade"))return "Homemade / nieznany";
        return enemyCards.size()<2?"Czekam na więcej kart":"Homemade / brak pewnego dopasowania";
    }
    private String possibleWins(){List<String> out=new ArrayList<>();for(String c:enemyCards)if(winConditions.contains(c))out.add(c);return out.isEmpty()?"jeszcze nie rozpoznano":android.text.TextUtils.join(", ",out)+" (hipoteza, nie pewnik)";}
    @Override public int onStartCommand(Intent i,int f,int id){return START_STICKY;}
    @Override public void onDestroy(){if(bubble!=null)wm.removeView(bubble);if(panel!=null)wm.removeView(panel);super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
}
