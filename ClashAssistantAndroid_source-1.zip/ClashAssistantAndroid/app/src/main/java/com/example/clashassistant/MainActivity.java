package com.example.clashassistant;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(22), dp(28), dp(22), dp(22));
        layout.setBackgroundColor(Color.rgb(10,16,32));
        TextView title = new TextView(this); title.setText("⚡ CLASH ASSISTANT"); title.setTextSize(25); title.setTextColor(Color.WHITE);
        layout.addView(title);
        TextView desc = new TextView(this); desc.setText("Android overlay prototype · deck tools"); desc.setTextColor(Color.LTGRAY); desc.setPadding(0,dp(8),0,dp(20)); layout.addView(desc);
        Button permission = button("1. Włącz wyświetlanie nad innymi aplikacjami");
        permission.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } else Toast.makeText(this,"Uprawnienie już jest włączone",Toast.LENGTH_SHORT).show();
        });
        layout.addView(permission);
        Button start = button("2. Uruchom pływający przycisk");
        start.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) { Toast.makeText(this,"Najpierw włącz uprawnienie overlay",Toast.LENGTH_LONG).show(); return; }
            startService(new Intent(this, OverlayService.class));
            Toast.makeText(this,"Przycisk asystenta uruchomiony",Toast.LENGTH_SHORT).show();
        });
        layout.addView(start);
        Button game = button("3. Otwórz Clash Royale");
        game.setOnClickListener(v -> {
            Intent launch = getPackageManager().getLaunchIntentForPackage("com.supercell.clashroyale");
            if (launch != null) startActivity(launch);
            else Toast.makeText(this,"Nie znaleziono Clash Royale — zainstaluj grę z Google Play",Toast.LENGTH_LONG).show();
        });
        layout.addView(game);
        TextView note = new TextView(this);
        note.setText("\nWażne: to prototyp. Analiza kart w meczu jest na razie ręczna. Aplikacja nie czyta jeszcze obrazu gry i nie modyfikuje plików Clash Royale.");
        note.setTextColor(Color.rgb(164,181,207)); note.setTextSize(13); layout.addView(note);
        setContentView(layout);
    }
    private Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setAllCaps(false); b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(31,54,84)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=dp(12); b.setLayoutParams(lp); return b;
    }
}
