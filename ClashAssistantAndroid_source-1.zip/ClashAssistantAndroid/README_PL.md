# Clash Assistant — prototyp Android

To jest **kod źródłowy projektu Android**, a nie gotowy APK.

## Co jest przygotowane
- ekran startowy,
- przycisk do uruchamiania Clash Royale (pakiet `com.supercell.clashroyale`),
- prośba o uprawnienie wyświetlania nad innymi aplikacjami,
- pływający przycisk `AI`,
- panel z zakładkami Deck / Finder / WinCon,
- ręczne dodawanie kart przeciwnika i bardzo podstawowe reguły rozpoznawania.

## Czego jeszcze nie ma
- automatycznego rozpoznawania kart z obrazu gry,
- pełnej bazy popularnych decków i prawdziwej analizy meta,
- prawdziwej analizy poziomów/Evo/Hero i rekomendacji,
- podpisanego, skompilowanego APK.

## Budowanie APK
Otwórz folder w Android Studio na komputerze, zsynchronizuj Gradle i wybierz **Build > Build APK(s)**. Wymagany Android SDK 35 i JDK zgodne z Android Gradle Plugin 8.7.3.
Na telefonie w ustawieniach Androida trzeba przyznać uprawnienie „Wyświetlanie nad innymi aplikacjami”. Overlay działa jako osobna aplikacja i nie modyfikuje plików gry.

To wczesny prototyp; testuj tylko zgodnie z regulaminem gry. Overlay i analiza obrazu mogą nie działać na każdym urządzeniu lub podczas każdej wersji gry.
